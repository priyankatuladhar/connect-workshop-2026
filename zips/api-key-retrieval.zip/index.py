import boto3
import cfnresponse

def handler(event, context):
    try:
        if event['RequestType'] == 'Delete':
            cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
            return

        props = event['ResourceProperties']
        client = boto3.client('apigateway')

        # Support both ApiKeyName (preferred) and ApiKeyId (legacy)
        if 'ApiKeyName' in props:
            key_name = props['ApiKeyName']
            paginator = client.get_paginator('get_api_keys')
            key_id = None
            for page in paginator.paginate(includeValues=False):
                for key in page['items']:
                    if key['name'] == key_name:
                        key_id = key['id']
                        break
                if key_id:
                    break
            if not key_id:
                raise ValueError(f"API key '{key_name}' not found")
        else:
            key_id = props['ApiKeyId']

        response = client.get_api_key(apiKey=key_id, includeValue=True)
        cfnresponse.send(event, context, cfnresponse.SUCCESS,
                         {'ApiKeyValue': response['value']})
    except Exception as e:
        print(f'ApiKey retrieval error: {e}')
        cfnresponse.send(event, context, cfnresponse.FAILED, {'Error': str(e)})
